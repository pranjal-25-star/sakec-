from flask import Flask, request

app = Flask(__name__)

@app.route('/feedback', methods=['POST'])
def feedback():
    name = request.form['name']
    email = request.form['email']
    msg = request.form['message']

    # Backend validation
    if not name or not email or not msg:
        return "All fields required!", 400
    if "@" not in email or "." not in email:
        return "Invalid email!", 400

    # Save or display feedback
    return f"Thank you {name}! Your feedback has been received."

if __name__ == '__main__':
    app.run(debug=True)
