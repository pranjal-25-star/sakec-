<?php
session_start();

$user = $_POST['username'];
$pass = $_POST['password'];

// Simple check (for demo)
if ($user == "admin" && $pass == "1234") {
    $_SESSION['user'] = $user;
    echo "Login successful!<br>";
    echo "<a href='logout.php'>Logout</a>";
} else {
    echo "Invalid username or password!";
}
?>
